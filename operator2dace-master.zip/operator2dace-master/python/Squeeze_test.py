#!/usr/bin/env python
# coding=utf-8
import tensorflow as tf
import numpy as np
import unittest
import os
import sys

this_dir = os.getcwd()
sys.path.append(os.path.join(this_dir, '..'))
from operator_testcase import OperatorTestCase

class SqueezeTestCase(OperatorTestCase):
#调用OperatorTestCase类
    def init_data(self):
        x1 = [
            [[-1, -1, -1],
             [4, 5, 6],
             [1, 1, 1]],

            [[-1, -2, -3],
             [1, 1, 1],
             [7, 8, 9]],
        ]
        x2 = [
            [[-2, -2, -2],
             [-2, -2, 2],
             [-2, -2, 2]],

            [[-1, -2, -3],
             [4, 5, 6],
             [1, 1, 1]]
        ]
        self.x = [np.array([x1]), np.array([x2])]
        #self.op_name = 'Squeeze'
        super(self.__class__, self).init_data()
    def tf_net(self):
        inputs = self.inputs()

        output = tf.squeeze(inputs,name=self.output_name)
        return output

if __name__ == '__main__':
    suite = unittest.TestSuite()
    suite.addTest(SqueezeTestCase("test"))

    runner = unittest.TextTestRunner()
    runner.run(suite)

