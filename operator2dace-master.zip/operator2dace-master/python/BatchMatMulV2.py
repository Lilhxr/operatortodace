#!/usr/bin/env python
# coding=utf-8
import tensorflow as tf
'''
此版本不需要unittest,placeholder保存数据，因为直接使用tf.Variable保存了
'''

def tf_net():
    batch_size=2

    #tf.reset_default_graph()

    a = tf.Variable(tf.random_normal(shape=(batch_size, 2, 3)))
    print(a)
    b = tf.Variable(tf.random_normal(shape=(batch_size, 3, 2)))
    print(b)

    output = tf.matmul(a, b, name="output")

    var_init = tf.global_variables_initializer()

    default_graph = tf.get_default_graph()

    # 启计算图，读入数据，生成output(对应def_tf-net的output)
    with tf.Session() as sess:
        sess.run(var_init)
        result_a = sess.run(a)
        result_b = sess.run(b)
        result = sess.run(output)
        #result = sess.run(output, feed_dict={input_a: a, input_b: b})

    print(result_a)
    print(result_b)
    print(result)



writer = tf.summary.FileWriter("./log", tf.get_default_graph())
writer.close()



if __name__ == '__main__':
    tf_net()