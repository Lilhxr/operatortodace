import tensorflow as tf


input1 = tf.constant([[7, 8, 9],[10, 11, 12]],name="input1")
input2 = tf.constant([[1, 2, 3],[4, 5, 6]],name="input2")

output1 = tf.stack([input1,input2], axis=0,name="stack1")
output2 = tf.stack([input1,input2], axis=1,name="stack2")

writer = tf.summary.FileWriter("./log", tf.get_default_graph())
writer.close()
