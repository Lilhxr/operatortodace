mport tensorflow as tf
import numpy as np

data_a = [
        [[1, 10, 100], [2, 20, 200]],
        [[3, 30, 300], [4, 40, 400]],
        [[5, 50, 500], [66, 60, 600]],
        ]
'''
data_a=[
        [[-1.6531624794]],[[-1.6467940807]],[[1.7231529951]],[[2.1495532990]],
        [[-0.1907231063]],[[-0.3459937274]],[[-0.6720248461]],[[-0.4797654450]]
        [[0.1195918992]],[[0.3754411340]],[[-0.4110670984]],[[-1.1883248091]],
        [[-1.1179131269]],[[0.5705596805]],[[2.0265667439]],[[1.2885936499]],
        [[-0.0543425865]],[[-0.6905589104]],[[-0.8635042310]][[-0.7113468647]],
        [[-0.4335775077]],[[-0.2078311145]],[[0.0294997375]],[[0.2547013760]],
        [[0.3945135176]],[[0.5557870269]],[[0.4849734008]],[[0.1154852137]],
        [[0.3627508879]],[[-0.0035985229]],[[-1.5567746162]],[[1.7761322260]]
         ]
'''

print (np.shape(data_a))
#begin_mask等都是标量
b  = tf.strided_slice(data_a, [0,0,0],[3,2,3],[1,1,1], 0, 0, 0, 0, 0)
b1 = tf.strided_slice(data_a, [1,0,0],[3,2,3],[1,1,1], 0, 0, 0, 0, 0)

b2 = tf.strided_slice(data_a, [0,0,0],[3,2,3],[1,1,1], 0, 0, 0, 0, 0)

#从坐标[1,1,2]开始走到[3,2,3] 步长为1 mask作用相当于一个判断 把对应index表示的坐标取0
b3 = tf.strided_slice(data_a, [1,1,2],[3,2,3],[1,1,1], 0, 0, 0, 0, 0)
b4 = tf.strided_slice(data_a, [1,1,2],[3,2,3],[1,1,1], 0b001, 0, 0, 0, 0)
b5 = tf.strided_slice(data_a, [1,1,2],[3,2,3],[1,1,1], 0b010, 0, 0, 0, 0)
b6 = tf.strided_slice(data_a, [1,1,2],[3,2,3],[1,1,1], 0, 0b001, 0, 0, 0)
b7 = tf.strided_slice(data_a, [1,1,2],[3,2,3],[1,1,1], 0b101, 0, 0, 0, 0)
b8 = tf.strided_slice(data_a, [1,1,2],[3,2,3],[1,1,1], 0, 0, 0b001, 0, 0)
b9 = tf.strided_slice(data_a, [1,1,2],[3,2,3],[1,1,1], 0, 0, 0b010, 0, 0)
b10 = tf.strided_slice(data_a, [0,0,0],[3,2,3],[1,1,1], 0, 0, 0, 0b001, 0)
b11 = tf.strided_slice(data_a, [0,0,0],[3,2,3],[2,1,1], 0, 0, 0, 0b010, 0)
b12 = tf.strided_slice(data_a, [0,0,0],[2,2,3],[1,1,1], 0, 0, 0, 0, 0b001)


with tf.Session() as session:
  session.run(tf.global_variables_initializer())
  out = session.run(b)
  out1 = session.run(b1)
  out2 = session.run(b2)
  out3 = session.run(b3)
  out4 = session.run(b4)
  out5 = session.run(b5)
  out6 = session.run(b6)
  out7 = session.run(b7)
  out8 = session.run(b8)
  out9 = session.run(b9)
  out10 = session.run(b10)
  out11 = session.run(b11)
  out12 = session.run(b12)
'''
print('b shape:', np.shape(out))
print(out)
print('b1 shape:', np.shape(out1))
print(out1)
'''
print('b2 shape:', np.shape(out2))
print(out2)

print('b3 shape:', np.shape(out3))
print(out3)

print('b4 shape:', np.shape(out4))
print(out4)

print('b5 shape:', np.shape(out5))
print(out5)

print('b6 shape:', np.shape(out6))
print(out6)

print('b7 shape:', np.shape(out7))
print(out7)

print('b8 shape:', np.shape(out8))
print(out8)

print('b9 shape:', np.shape(out9))
print(out9)

print('b10 shape:', np.shape(out10))
print(out10)

print('b11 shape:', np.shape(out11))
print(out11)

print('b12 shape:', np.shape(out12))
print(out12)

writer = tf.summary.FileWriter("./log", tf.get_default_graph())
writer.close()
