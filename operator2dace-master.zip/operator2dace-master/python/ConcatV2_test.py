#!/usr/bin/env python
# coding=utf-8
import tensorflow as tf
import numpy as np
import unittest
import os
import sys

this_dir = os.getcwd()
sys.path.append(os.path.join(this_dir, '..'))
from operator_testcase import OperatorTestCase

class ConcatTestCase(OperatorTestCase):
#调用OperatorTestCase类
    def init_data(self):

        x = [[[1, 2], [2, 3]], [[4, 4], [5, 3]]]

        y = [[[7, 4], [8, 4]], [[2, 10], [15, 11]]]
        self.x = [np.array([x]),np.array([y])]
        #self.op_name = 'Concat'
        super(self.__class__, self).init_data()
    def tf_net(self):
        inputs = self.inputs()

        output = tf.concat(inputs[0],1,name=self.output_name)
        #output = tf.concat((inputs[0,1],0),name=self.output_name)
        #output = tf.raw_ops.TensorArrayConcatV2(inputs,name=self.output_name)
        return output

if __name__ == '__main__':
    suite = unittest.TestSuite()
    suite.addTest(ConcatTestCase("test"))

    runner = unittest.TextTestRunner()
    runner.run(suite)