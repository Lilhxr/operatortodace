#!/usr/bin/env python
# coding=utf-8
import tensorflow as tf
import numpy as np
import unittest
import os
import sys

this_dir = os.getcwd()
sys.path.append(os.path.join(this_dir, '..'))
from operator_testcase import OperatorTestCase

class PowTestCase(OperatorTestCase):
#调用OperatorTestCase类
    def init_data(self):

        data1 = [[2,2],[3,3]]

        data2= [[8,16],[2,3]]

        self.x = [np.array([data1])]
        self.y = [np.array([data2])]

        self.input_x_name = 'input_x'
        self.input_y_name = 'input_y'
        self.output_name = 'output'
        self.inputshapes = list()
        self.input_x_names = list()
        self.input_y_names = list()

        for i in range(len(self.x)):
            inputshape = list(self.x[i].shape)
            inputshape = inputshape[1:]
            self.inputshapes.append(inputshape)

            input_name = "%s_%s" % (self.input_x_name, i)
            self.input_x_names.append(input_name)

            input_name = "%s_%s" % (self.input_y_name, i)
            self.input_y_names.append(input_name)

        print("inputshapes=%s" % self.inputshapes)

    def inputs(self):
        tf.reset_default_graph()

        inputs_x = list()
        inputs_y = list()

        for i in range(len(self.x)):

            inputs_x = tf.placeholder(dtype=tf.float32, shape=[None] + self.inputshapes[i],
                                      name="%s_%s" % (self.input_x_name, i))

            inputs_y = tf.placeholder(dtype=tf.float32, shape=[None] + self.inputshapes[i],
                                      name="%s_%s" % (self.input_y_name, i))
        return inputs_x, inputs_y

    def tf_net(self):
        inputs = self.inputs()

        output = tf.pow(inputs[0], inputs[1], name=self.output_name)
        output = tf.matmul
        #TypeError: pow() missing 1 required positional argument: 'y'
        return output

    def save_ckpt(self):
        self.tf_net()
        var_init = tf.global_variables_initializer()
        feed_dict = dict() # input and output

        for i in range(0, len(self.x)):
            input = tf.get_default_graph().get_tensor_by_name(
                "%s:0" % self.input_x_names[i])
            feed_dict[input] = self.x[i]

        for i in range(0, len(self.y)):
            input = tf.get_default_graph().get_tensor_by_name(
                "%s:0" % self.input_y_names[i])
            feed_dict[input] = self.y[i]



        default_graph = tf.get_default_graph()
        output = default_graph.get_tensor_by_name("%s:0" % self.output_name)

        with tf.compat.v1.Session() as sess:
            sess.run(var_init)
            result = sess.run(output, feed_dict=feed_dict)
            print(result)

            # 启动计算图，读入数据，生成output(对应def_tf-net的output)
            with tf.Session() as sess:
                sess.run(var_init)
                result = sess.run(output, feed_dict=feed_dict)
                # 需要将result写入一个txt文档保存
                # self.result_write_to_file(
                #     result.astype("int32"), self.__class__.__name__ + "Result.txt"
                # )
                return result


if __name__ == '__main__':
    suite = unittest.TestSuite()
    suite.addTest(PowTestCase("test"))

    runner = unittest.TextTestRunner()
    runner.run(suite)