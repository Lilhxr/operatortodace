# Dace Missing Operator Test
[![Travis build status](https://travis-ci.org/tensorflow/tensorboard.svg?branch=master)](https://travis-ci.org/tensorflow/tensorboard/)

#### [算子查询](https://www.tensorflow.org/api_docs/python/tf)


   #### 环境：Tensorflow 1.14

 #### unittest是python内置的用于测试代码的模块，无需安装， 使用简单方便
 ```
    pip install unittest2
```
unittest case的运行流程：

1.  写好一个完整TestCase
2.  多个TestCase 由TestLoder被加载到TestSuite里面, TestSuite也可以嵌套TestSuite
3.  由TextTestRunner来执行TestSuite，测试的结果保存在TextTestResult中
4.  TestFixture指的是环境准备和恢复

                                                              缺失统计

|             | `sin` | `sum`  | `neg`  | `pow`   | `squee`  | `Transpose` | `BatchMatMuiV2`| `ConcatV2`| `ExtractImagePatches`|
|-------------|-------|--------|--------|---------|--------  |-------      |-------         |---------- |--------------------  |
| **Linux/Win**|  ✅   |   ✅  |   ✅  |   ✅    |    ✅   |     ✅      |       ✅       |    ✅    |          ✅          |
| **继承父类**|        |        |        | ❌     |         |              |    ❌          |          |         ❌          |    
| **operation**|正弦   |  求和  |   取反 |  下标求幂| 删维度  |  数组转置  | 批数据Tensor乘积 |  合并     |  提取图像的像素块  |
| **input**|   | array|  array  |  array |         |  array  |              |      Tensor    |           |                      |
| **output**|  |      |         |        |  Tensor |         |              |                |   array    |        Tensor        |

